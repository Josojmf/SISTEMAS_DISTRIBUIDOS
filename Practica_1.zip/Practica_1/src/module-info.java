/**
 * 
 */
/**
 * @author ALUMNOS
 *
 */
module Practica_1 {
	requires java.logging;
}